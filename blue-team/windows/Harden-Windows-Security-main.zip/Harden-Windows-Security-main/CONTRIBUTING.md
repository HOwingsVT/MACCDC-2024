Any contribution and suggestion is welcome. I'll review them and implement them if they comply with the standards and positively improve the repository.
