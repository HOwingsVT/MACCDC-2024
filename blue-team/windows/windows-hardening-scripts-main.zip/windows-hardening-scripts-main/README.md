# A collection of Windows Server 2019 and Windows 10 hardening scripts

<img src="https://github.com/atlantsecurity/windows-hardening-scripts/blob/main/windows-hardening-scripts.png?raw=true" />

Our team regularly runs hardening exercises for clients and thus we previously used DISA GPOs and hardentools, then we tested several hardening scripts off github and found them to be quite buggy - some of them disabled crucial Windows functionality even for regular users. 

So we forked some of them and started editing them on our repository (giving credit where credit is due!). 

Changes and comments are welcome. 
