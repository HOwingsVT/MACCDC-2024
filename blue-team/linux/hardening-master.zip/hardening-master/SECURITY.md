# Security Policy

## Supported Versions

The current [upstream](https://github.com/konstruktoid/hardening)
and the [latest published version](https://github.com/konstruktoid/hardening/releases) are supported.

## Reporting a Bug or Vulnerability

If you found a bug or vulnerability or just something odd, feel free to submit a issue or improve the code by creating a pull request.
