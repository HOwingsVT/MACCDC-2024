#!/bin/sh
# Contributed by Barry Allard in 2.4.2.3 fork (github.com/steakknife/tripwire)
git clean -dff
git clean -Xff
rm -rf autom4te.cache
