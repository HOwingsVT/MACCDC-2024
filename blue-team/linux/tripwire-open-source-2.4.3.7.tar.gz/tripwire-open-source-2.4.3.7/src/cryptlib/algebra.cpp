// algebra.cpp - written and placed in the public domain by Wei Dai

#include "pch.h"
#include "integer.h"
#include "algebra.h"

